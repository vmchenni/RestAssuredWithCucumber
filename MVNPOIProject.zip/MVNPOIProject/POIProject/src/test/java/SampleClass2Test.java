import org.testng.annotations.Test;

public class SampleClass2Test {
    @Test
    public void fnMySecondFunction(){
        System.out.println("InsideSecondFunction");
    }
}
