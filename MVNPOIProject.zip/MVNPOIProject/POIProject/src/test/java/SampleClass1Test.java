import org.testng.annotations.Test;

public class SampleClass1Test {
    @Test
    public void fnMyFirstFunction(){
        System.out.println("Inside fnMyFirstFunction");
    }
}
